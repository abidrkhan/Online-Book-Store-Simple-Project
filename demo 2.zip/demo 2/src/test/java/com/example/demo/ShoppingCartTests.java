package com.example.demo;


import com.example.demo.cart.CartItemtest;
import com.example.demo.cart.CartItemRepository;
import com.example.demo.book.Book;
import com.example.demo.student.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;


import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class ShoppingCartTests {

    @Autowired
    private CartItemRepository cartRepo;

    //TestEntityManager provides a subset of EntityManager methods
    // that are useful for tests or testing tasks
    @Autowired
    private TestEntityManager entityManager;

    //Testing Method
    @Test
    public void testAddCartItem() {
        Book book = entityManager.find(Book.class, 3);
        Student student = entityManager.find(Student.class, 2);

        CartItemtest cartItem = new CartItemtest();
        cartItem.setStudent(student);
        cartItem.setBook(book);
        cartItem.setQuantity(1);

        System.out.println("Test student " + student);
        System.out.println("Test book " + book);

        CartItemtest savedCartItem = cartRepo.save(cartItem);
        assertTrue(savedCartItem.getCart_item_id() > 0);

    }

    @Test
    public void testCartItemByCustomer() {
       Student student = new Student();
       student.setStudent_id(1);

       List<CartItemtest> cartItems = cartRepo.findByStudent(student);
       assertEquals(2,cartItems.size());


    }
}
