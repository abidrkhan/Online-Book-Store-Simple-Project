package com.example.demo.book;

import javax.persistence.*;

@Entity
@Table
public class Book {


    @Id
    @SequenceGenerator(
            name = "book_sequence",
            sequenceName = "book_sequence",
            allocationSize = 1
    )

    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "book_sequence"
    )
    private Long book_id;
    private String book_isbn;
    private String book_name;
    private String book_author;
    private long book_price;
    private String book_image;

    public Book() {
    }

    public Book(Long book_id) {
        this.book_id = book_id;
    }

    public Book(String book_isbn, String book_name, String book_author, long book_price, String book_image) {
        this.book_isbn = book_isbn;
        this.book_name = book_name;
        this.book_author = book_author;
        this.book_price = book_price;
        this.book_image = book_image;
    }

    public Book(Long book_id, String book_isbn, String book_name, String book_author, long book_price, String book_image) {
        this.book_id = book_id;
        this.book_isbn = book_isbn;
        this.book_name = book_name;
        this.book_author = book_author;
        this.book_price = book_price;
        this.book_image = book_image;
    }

    public Long getBook_id() {
        return book_id;
    }

    public void setBook_id(Long book_id) {
        this.book_id = book_id;
    }

    public String getBook_isbn() {
        return book_isbn;
    }

    public void setBook_isbn(String book_isbn) {
        this.book_isbn = book_isbn;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getBook_author() {
        return book_author;
    }

    public void setBook_author(String book_author) {
        this.book_author = book_author;
    }

    public long getBook_price() {
        return book_price;
    }

    public void setBook_price(long book_price) {
        this.book_price = book_price;
    }

    public String getBook_image() {
        return book_image;
    }

    public void setBook_image(String book_image) {
        this.book_image = book_image;
    }

    @Override
    public String toString() {
        return "Book{" +
                "book_id=" + book_id +
                ", book_isbn='" + book_isbn + '\'' +
                ", book_name='" + book_name + '\'' +
                ", book_author='" + book_author + '\'' +
                ", book_price=" + book_price +
                ", book_image='" + book_image + '\'' +
                '}';
    }
}

