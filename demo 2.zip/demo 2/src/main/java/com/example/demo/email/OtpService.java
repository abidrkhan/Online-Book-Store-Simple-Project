package com.example.demo.email;
import java.util.Random;
import org.springframework.stereotype.Service;


@Service
public class OtpService {



        public int generateOTP(){
            Random random = new Random();
            int otp = 1000 + random.nextInt(9000);
            //otpCache.put(key, otp);
            System.out.println(otp);
            return otp;
        }


    }



