package com.example.demo.book;

import com.example.demo.cart.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.List;

@Service
public class BookService {

    public BookRepository bookRepository;

    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> getBooks() {
        return bookRepository.findAll();
    }


    public int isExists (Long book_id, List <Item> objList){
        for (int i = 0; i < objList.size(); i++) {
            if (objList.get(i).getBook().getBook_id() == book_id) {
                return i;
            }
        }
        return -1;
    }

    public double cartTotal(HttpSession session){
        List<Item> objList = (List<Item>) session.getAttribute("cart");
        double cartTotalAmount = 0;
        for (int i=0; i<objList.size(); i++) {
            cartTotalAmount = cartTotalAmount + objList.get(i).getQuantity() * objList.get(i).getBook().getBook_price();
        }
         return cartTotalAmount;

        }









}



