package com.example.demo.student;


import com.example.demo.book.Book;
import com.example.demo.book.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.List;

@Configuration
public class StudentConfig {

    private final BCryptPasswordEncoder passwordEncoder;

    public StudentConfig(BCryptPasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    CommandLineRunner commandLineRunner(StudentRepository studentRepository, BookRepository bookRepository)
    {
     return args -> {
         Student abc = new Student(
                 "abc",
                 "abc@gmail.com",
                 passwordEncoder.encode("abc123"));

         Student xyz = new Student(
                 "xyz",
                 "xyz@gmail.com",
                 passwordEncoder.encode("abc123"));


         Student  ali = new Student(
                 "Ali",
                 "ali@gmail.com",
                 passwordEncoder.encode("abc123"));

         Student  h = new Student(
                 "H",
                 "h@gmail.com",
                 passwordEncoder.encode("abc123"));

         Student tom = new Student(
                 "Tom",
                 "tom@gmail.com",
                 passwordEncoder.encode("abc123"));


         Student  jerry = new Student(
                 "JERRY",
                 "jerry@gmail.com",
                 passwordEncoder.encode("abc123"));


         Book english = new Book(
                 "1234-567-890",
                 "English",
                 "Oxford",
                 500,
                 "english.jpg");

         Book math = new Book(
                 "1234-567-891",
                 "Primary Maths",
                 "Macmillan",
                 1000,
                 "math.jpg");

         Book science = new Book(
                 "1234-567-892",
                 "Secondary Science 2",
                 "Oxford",
                 1200,
                 "science.jpg");

         Book urdu = new Book(
                 "1234-567-790",
                 "Urdu",
                 "Prof Ali Akber",
                 600,
                 "urdu.jpg");

         Book computer = new Book(
                 "1234-567-691",
                 "Computer Science",
                 "Inter Board",
                 700,
                 "computer.jpg");

         Book islamiat = new Book(
                 "1234-567-892",
                 "Islamiat",
                 "Sindh Board",
                 350,
                 "islamiat.jpg");

         studentRepository.saveAll(List.of(abc,xyz,ali,h,tom,jerry));
         bookRepository.saveAll(List.of(english,math,science,urdu,computer,islamiat));



     };
    }

}
