package com.example.demo.student;

import com.example.demo.book.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class StudentService {
    public StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {

        this.studentRepository = studentRepository;
    }

//    public List<Student> getStudents() {
//        return studentRepository.findAll();
//    }


    public String authenticatedUserCheck(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication instanceof AnonymousAuthenticationToken)
        {
            System.out.println("user not logged in to view books");
            return "notAuthenticated";
        }
        else{
            return "authenticated";
            }
    }



}
