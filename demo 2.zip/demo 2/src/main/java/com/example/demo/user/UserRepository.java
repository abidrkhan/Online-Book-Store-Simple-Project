package com.example.demo.user;

import com.example.demo.student.Student;
import org.hibernate.metamodel.model.convert.spi.JpaAttributeConverter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserRepository extends JpaRepository <Student,Integer> {
    @Query("Select s from Student s where s.email = :myEmail")
    Student getStudentByName(@Param("myEmail") String email);
}
