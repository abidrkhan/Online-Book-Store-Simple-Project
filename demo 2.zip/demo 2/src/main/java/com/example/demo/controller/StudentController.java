package com.example.demo.controller;

import com.example.demo.book.Book;
import com.example.demo.book.BookRepository;
import com.example.demo.book.BookService;
import com.example.demo.cart.Item;
import com.example.demo.email.EmailService;
import com.example.demo.email.OtpService;
import com.example.demo.student.Student;
import com.example.demo.student.StudentRepository;
import com.example.demo.student.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SessionAttributes()
@Controller
public class StudentController {

    private final BCryptPasswordEncoder passwordEncoder;
    //reference
    private final StudentService studentService;
    private final OtpService otpService;
    private final EmailService emailService;
    private final BookService bookService;

    private final StudentRepository repo;

    private final BookRepository bookRepo;


    Student student = new Student();

    public String userName;
    public String userEmail;
    public String userPass;
    public long otp;
    public String returnString;
    public String authCheck;
    public String authCheckLogout;
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();


    @Autowired
    public StudentController(StudentService studentService, OtpService otpService, EmailService emailService, BookService bookService, StudentRepository repo, BCryptPasswordEncoder passwordEncoder, BookRepository bookRepo) {
        this.otpService = otpService;
        this.emailService = emailService;
        this.studentService = studentService;
        this.bookService = bookService;
        this.repo = repo;
        this.passwordEncoder = passwordEncoder;
        this.bookRepo = bookRepo;

    }

    @GetMapping("")
    public String welcomePage(Model model) {
        model.addAttribute("pageTitle", "home");
        return "welcome";
    }


    // Login form
    @RequestMapping("/login")
    public String login(HttpSession session) {

        session.removeAttribute("cart");
        authCheck = "";
        authCheck = studentService.authenticatedUserCheck();
        if (authCheck.equals("authenticated")) {
            System.out.println("Authenticated User /login");
            return "login1";
        } else {
            System.out.println("else: User is not authenticated, login first /login - ark");
            return "login0";
        }
    }


    // Login with error
    @RequestMapping("/login-error")
    public String loginError(Model model) {
        model.addAttribute("loginError", true);
        return "login0";
    }


    //Login Success
    @GetMapping("/logged-in")
    public String loggedIn() {
        return "login1";
        //return "login_2";
    }


    @GetMapping("/books")
    public String BookPage(Model model, HttpSession session) {
        authCheck = "";
        authCheck = studentService.authenticatedUserCheck();
        if (authCheck.equals("authenticated")) {
            List<Book> listOfBooks = bookService.getBooks();
            model.addAttribute("book_model", listOfBooks);
            System.out.println("Authenticated User /books");
            return "book_index";
        } else {
            System.out.println("else: User is not authenticated, login first /books");
            return "login0";
        }
    }


    @GetMapping("cart/buy/{book_id}")
    public String buy(@PathVariable("book_id") Long book_id, Model model, HttpSession session) {

        Optional<Book> book = bookRepo.findById(book_id);

        if (book.isPresent()) {    //if statement #1
            Book bk = book.get();

            if (session.getAttribute("cart") == null) {
                List<Item> objList = new ArrayList<>();
                objList.add(new Item(bk, 1));
                session.setAttribute("cart", objList);
            } else { //else #1
                List<Item> objList = (List<Item>) session.getAttribute("cart");
                int i = bookService.isExists(book_id, objList);

                if (i == -1) {
                    objList.add(new Item(bk, 1));
                } else {
                    long quantity = objList.get(i).getQuantity() + 1;
                    objList.get(i).setQuantity(quantity);
                }

                session.setAttribute("cart", objList);
            } //else #1

            double total = bookService.cartTotal(session);
            System.out.println(total);
            model.addAttribute("cart_total", total);
        }  // if statement # 1

        return "cart";
    }


    @GetMapping("cart/remove{book_id}")
    public String removeFromCart(@PathVariable Long book_id, HttpSession session, Model model) {
        List<Item> objList = (List<Item>) session.getAttribute("cart");
        int i = bookService.isExists(book_id, objList);
        objList.remove(i);
        session.setAttribute("cart", objList);

        double total = bookService.cartTotal(session);
        System.out.println(total);
        model.addAttribute("cart_total", total);
        return "cart";
    }




    @GetMapping("cart/checkout")
    public String checkoutCart(HttpSession session, Model model) {
        List<Item> objList = (List<Item>) session.getAttribute("cart");
        session.setAttribute("cart", objList);

        double total = bookService.cartTotal(session);
        System.out.println(total);
        model.addAttribute("cart_total", total);
        return "checkout";
    }




    @GetMapping("/register_student")
    public String registerStudentPage(Model model) {
        //Student student = new Student();
        model.addAttribute("student_attribute", student);

        return "register";
    }




    @PostMapping("/verify-otp")
    public String verifyOtp(@ModelAttribute Student student, Model model, HttpSession session) {

        userName = student.getName();
        userEmail = student.getEmail();
        userPass = student.getPass();

        // Get OTP
        this.otp = otpService.generateOTP();
        System.out.println("OTP is " + otp);

        //Send Email
        String otp_message = "Your OTP is " + otp;
        boolean emailChk = this.emailService.sendEmail(otp_message, "Student Registration OTP", userEmail);
        System.out.println("boolean emailChk" + emailChk);


        session.setAttribute("myOtp", otp);


        System.out.println("I am at return verify otp of verifyOtp.........");
        return "verify_otp";
    }


    @PostMapping("/save-data")
    public String saveData(@RequestParam("otp") long otp, HttpSession session) {


        Student student = new Student();
        student.setName(userName);
        student.setEmail(userEmail);
        student.setPass(passwordEncoder.encode(userPass));


        long myOtp = (long) session.getAttribute("myOtp");
        //String myEmail= (String) session.getAttribute("session_email");

        if (myOtp == otp) {
            repo.save(student);
            System.out.println("if otp...........");
            System.out.println("Data saved.........");
            //returnString = "redirect:/login";
            returnString = "register_success";
        } else {
            returnString = "wrong_otp";
            System.out.println("Inside else.......");
        }

        return returnString;

    }
}


